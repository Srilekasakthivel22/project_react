import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import './MyProfile.css';
import './EditProfile';


export default class MyProfile extends Component {
constructor(props)
{
        super(props);
        this.state={
            Employee:[],
            employeeId:"",
            employeePassword:"",
            fullName:"",
            employeeEmailId:"",
            employeeMobileNo:"",
            employeeDoj:"",
            employeeDept:"",
            managerId:""

        }
        this.SearchById=this.SearchById.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.SignOut=this.SignOut.bind(this);
        this.edit=this.edit.bind(this);
       
}
SearchById()
{
    let id=sessionStorage.getItem("EmpId");
    let url="http://localhost:20969/api/Employee/"+id;
    axios.get(url).then(response=>{
        this.setState({
            employeeId:response.data.employeeId,
            employeePassword:response.data.emplyeePassword,
            fullName:response.data.fullName,
            employeeEmailId:response.data.employeeEmailId,
            employeeMobileNo:response.data.employeeMobileNo,
            employeeDoj:response.data.employeeDoj,
            employeeDept:response.data.employeeDept,
            managerId:response.data.managerId
        })
    }).catch(err=>{
        console.warn(err);
    })
    if(id==null)
        {
            alert("Pls Login First");
            window.location="/EmpLogin";
        }
}
SignOut()
    {
        sessionStorage.removeItem("EmpId");
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Empname");
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";

    }

handleChange(e)
{
    this.setState(e);
}
componentDidMount()
{
    this.SearchById();
   
        
    
}
edit()
{
    window.location="./EditProfile";
}


    render() {
        const {employeeId}=this.state;
        const {employeePassword}=this.state;
        const {fullName}=this.state;
        const {employeeEmailId}=this.state;
        const {employeeMobileNo}=this.state;
        const {employeeDoj}=this.state;
        const {employeeDept}=this.state;
        const {managerId}=this.state;
        return (
            <div >
                <div className="back">
                
                    <label>My Details</label><br></br>
             <div className="t">   
             <table >
                 <tr>
                 <th>  EmployeeId</th>
              <th> FullName </th>
              <th> EmailId  </th> 
              <th> Mobile number</th> 
               <th> Doj  </th>
              <th> Dept   </th>
              <th> ManagerId</th>
                 </tr>
                 <tr>
              <td>  {employeeId}</td>
              <td>{fullName}<br></br></td> 
            
              <td> {employeeEmailId}<br></br></td> 
              <td> {employeeMobileNo}<br></br></td> 
               <td> {employeeDoj}<br></br></td>
              <td> {employeeDept}<br></br></td> 
              <td> {managerId}<br></br></td> 
                </tr>
                </table>
                {/* <button type="submit" onClick={this.SearchById}>Profile</button> */}
                <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>
                <Button variant="primary btn-block" onClick={this.edit} > Edit My details </Button>

                
                </div>
              
                </div>
            </div>
        )
    }
}
