import logo from './logo.svg';
import './App.css';
import Login from './LoginPortal/Login';
import ManagerLogin from './Manager/ManagerLogin';
import EmpDashBoard from './Emp/EmpDashBoard';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import EmpLogin from './Emp/EmpLogin';
import Register from './Emp/Register';
import MyManagerDetails from './Emp/MyManagerDetails';
import MyProfile from './Emp/MyProfile';
import LeaveTracker from './Emp/LeaveTracker';
import EditProfile from './Emp/EditProfile';
import ManagerRegister from './Manager/ManagerRegister';

import Profile from './Manager/Profile';
import LeaveApplication from './Manager/LeaveApplication';
import ManagerDashBoard from './Manager/ManagerDashBoard';
import EditManager from './Manager/EditManager';
import ApplyLeave from './Emp/ApplyLeave';
import ViewLeave from './Emp/ViewLeave';
import EmployeesDeatils from './Manager/EmployeesDeatils';
import AppOrDeny from './Manager/AppOrDeny';
import AppDeny from './Manager/AppDeny'


function App() {
  return (
    <div className="App">
     <BrowserRouter>
            
            {/* <Link to="/EmpDashBoard">EmpDashBoard</Link><br></br> */}
            <Routes>
              <Route path="/" element={<Login/>}></Route>
            <Route path="/ManagerLogin" element={<ManagerLogin/>}></Route>
                <Route path="/EmpDashBoard" element={<EmpDashBoard/>}></Route>
                <Route path="/EmpLogin" element={<EmpLogin/>}></Route>
                <Route path="/Register" element={<Register/>}></Route>
                <Route path="/MyProfile" element={<MyProfile/>}></Route>
                <Route path="/EditProfile" element={<EditProfile/>}></Route>
                <Route path="/MyManagerDetails" element={<MyManagerDetails/>}></Route>
                <Route path="/LeaveTracker" element={<LeaveTracker/>}></Route>
                <Route path="/ManagerRegister" element={<ManagerRegister/>}></Route>
                <Route path="/ManagerDashBoard" element={<ManagerDashBoard/>}></Route>
                <Route path="/Profile" element={<Profile/>}></Route>
                <Route path="/LeaveApplication" element={<LeaveApplication/>}></Route>
                <Route path="/EditManager" element={<EditManager/>}></Route>
                <Route path="/ApplyLeave" element={<ApplyLeave/>}></Route>
                <Route path="/ViewLeave" element={<ViewLeave/>}></Route>
                <Route path="/EmployeesDetails" element={<EmployeesDeatils/>}></Route>
                <Route path="/AppOrDeny" element={<AppOrDeny/>}></Route>
                <Route path="/AppDeny" element={<AppDeny/>}></Route>
                
            </Routes>
    </BrowserRouter> 
    </div>
  );
}

export default App;
