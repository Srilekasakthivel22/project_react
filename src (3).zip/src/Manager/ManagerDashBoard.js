import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import Loginimage from './image/Loginimage.jpg'



export default class ManagerDashBoard extends Component {
    constructor()
    {
        super();
        this.state={
            Employee:[],
            Id:""

        }
        this.SignOut=this.SignOut.bind(this);
    }
    SignOut()
    {
        
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Mangname");
        sessionStorage.removeItem("email");
        window.location="/ManagerLogin";

    }
    componentDidMount()
    {
        let MgId=sessionStorage.getItem("MangId");
        let name=sessionStorage.getItem("Mangname");
        let email=sessionStorage.getItem("email");
        sessionStorage.setItem("Id",MgId);
        sessionStorage.setItem("Mname",name);
        sessionStorage.setItem("emailid",email);
        if(this.email==null)
        {
            alert("Pls Login First");
            window.location="/ManagerLogin";
        }
    }
    // Application()
    // {}
    // // {
    // //     sessionStorage.getItem("")
    // //     sessionStorage.setItem("MgId",)
    // }

    render() {
           this.id=sessionStorage.getItem("MangId");
        //     this.name=sessionStorage.getItem("Mangname");
            this.email=sessionStorage.getItem("email");
        return (
            <Container >
            <Row>
                <Col lg={4} md={6} sm={12} className="text-center mt-5 p-18">
                    
                    <div classname="b">
            <div>
                    Welcome {this.name},

                    <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>
            
                    <div  >
                <div className="yah">
                 <Link to="/Profile">MyProfile</Link><br></br>
                 </div>
                <div className="yah"></div>
                 
                 <Link to="/LeaveApplication" onClick={this.Application}>LeaveApplication</Link><br></br>
                 
            </div>
            </div>
            </div>
            
            </Col>
                       <Col lg={8} md={6} sm={12}>
                        <img className="w100" src={Loginimage} alt=""/>
                       </Col>

                   </Row>
               </Container>

               
        )
    }
}
