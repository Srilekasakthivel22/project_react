import React, { Component } from 'react'

import './ManagerRegister.css'
import axios from 'axios';



export default class Register extends Component {
constructor()
{
        super();
        this.state={
            ManagerPassword:"",
            FullName:"",
            ManagerEmailId:"",
            ManagerMobileNo:"",
           

        }
        this.Addnew=this.Addnew.bind(this);
        this.handleChange=this.handleChange.bind(this);

}
handleChange(e)
{
    this.setState(e);
}
Addnew()
{
    let url="http://localhost:20969/api/Manager";
    axios.post(url,{
        FullName:this.state.FullName,
        ManagerPassword:this.state.ManagerPassword,
        ManagerEmailId:this.state.ManagerEmailId,
        ManagerMobileNo:this.state.ManagerMobileNo,
        
    }).then(response=>{
        alert("Registration Completed Successfully");
        window.location="./ManagerLogin";
    }).catch(err=>{
        alert(err);
    })
    
}
 
    render() {

        return (
            
            
            <div className="background">
            <div  >
                
                
                <form className="box" >
                <h2 className="h2">Registration</h2>
                   <div >
                       
                        {/* <lable className="lable"> Id</lable> */}
                        {/* <input type="number" name="EmployeeId" placeholder=" Enter your id"></input>
                        <br/> */}
                        <label>FullName</label>
                        <input type="text" name="FullName" onChange={(e)=>this.handleChange({FullName:e.target.value})} placeholder=" Enter your Name"></input>
                        <br/>
                        <label>Password</label>
                        <input type="password" name="ManagerPassword" onChange={(e)=>this.handleChange({ManagerPassword:e.target.value})} placeholder=" Enter your password"></input>
                        <br/>
                        <label>EmailId</label>
                        <input type="emailid" name="ManagerEmailId" onChange={(e)=>this.handleChange({ManagerEmailId:e.target.value})}placeholder=" Enter your EmailId"></input>
                        <br/>
                        <label>MobileNo</label>
                        <input type="text" name="ManagerMobileNo" onChange={(e)=>this.handleChange({ManagerMobileNo:e.target.value})} placeholder=" Enter your Mobile number"></input>
                        <br/>
                       
                        <button type="submit" className="button" onClick={this.Addnew} >Register</button>
                    </div>
                   
                </form>
                
            </div>
            </div>
        )
    }
}
