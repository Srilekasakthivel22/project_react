import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'

export default class AppDeny extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            Leave:[],
            leaveId:"",
            status:"",
            managerComment:"",
        }
        this.update=this.update.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }
    handleChange(e)
    {
        this.setState(e);
    }
    update(e)
    {
        let id=sessionStorage.getItem("lid");
        alert(id);
        let url="http://localhost:20969/api/Leave?levid="+id;
        axios.put(url,{
            status:this.state.status,
            managerComment:this.state.managerComment,
        }).then(response=>{
            alert("status Changed");
            window.location="./AppOrDeny";
        }).catch(err=>{
            alert(err);
        })
    }
    componentDidMount()
    {
        this.update();
    }
    render(){
        let id=sessionStorage.getItem("empid");
    return(
       <div>
           <h2>Change Status</h2>
           <div>
      
       <label>Status</label>
       <input type="text" name="status" onChange={(e)=>this.handleChange({status:e.target.value})} ></input>
       <br/>
       <label>Comment</label>
       <input type="text" name="managerComments" onChange={(e)=>this.handleChange({managerComments:e.target.value})} ></input>
       <br/>
        <Button type="submit" className="button" onClick={this.update}>Submit</Button>
       </div>
       </div>

    )}
}