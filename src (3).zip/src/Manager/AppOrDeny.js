import axios from 'axios';
import React, { Component } from 'react'
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'



export default class AppOrDeny extends Component {
    constructor()
    {
        super();
        this.state={
            Leave:[],
            leaveId:"",
            employeeId:"",
            managerId:"",
            startDate:"",
            endDate:"",
            noOfDays:"",
            leaveType:"",
            leaveReason:"",
            Status:"",
            managerComment:"",
           
        }
      this.handleChange=this.handleChange.bind(this);
       this.ApproveDeny=this.ApproveDeny.bind(this);
 }
 ApproveDeny(e)
 {
     
    let id=sessionStorage.getItem("Id");
    
     let name=sessionStorage.getItem("Mname");
     let url="http://localhost:20969/api/Employee/"+id;
     axios.get(url).then(response=>{
         this.setState({
             leaveId:response.data.leaveId,
             employeeId:response.data.employeeId,
             managerId:response.data.managerId,
             startDate:response.data.startDate,
             endDate:response.data.endDate,
             noOfDays:response.data.noOfDays,
             leaveType:response.data.leaveReason,
             leaveReason:response.data.leaveReason,
             status:response.data.status,
             managerComment:response.data.managerComment,
         })
      sessionStorage.setItem("lid",response.data.leaveId);
      alert(response.data.leaveId);
    //   alert(res.data.leaveId);

      
       

       
       
    }).catch(error=>{
        alert(error);
    })
    
   
 }
 handleChange(e)
 {
     this.setState(e);
 }
 componentDidMount()
 {
  
    let MgId=sessionStorage.getItem("Id");
    let name=sessionStorage.getItem("Mname");
    let email=sessionStorage.getItem("Emailid");
    sessionStorage.setItem("Id",MgId);
    sessionStorage.setItem("Mname",name);
    sessionStorage.setItem("EmailId",email);
   
    // sessionStorage.getItem("empid",employeeId);
    this.ApproveDeny();
 }
Change()
{
    sessionStorage.setItem("lid",leaveId);
    window.location="./AppDeny"
}


 
    render() {
        const {Leave}=this.state;
        const {leaveId}=this.state;
        const {employeeId}=this.state;
        const {managerId}=this.state;
        const {startDate}=this.state;
        return (
           
                <div>
            <div>ShowAllDetails</div>
            
        <table  border="1" align='center'>
            <tbody>
            
            <tr>
            <th>LeaveId</th>
            <th>EmployeeId</th>
            <th>ManagerID</th>
            
            <th>StartDay</th>
            <th>EndDay</th>
            <th>noOfDay</th>
            <th>LeaveType</th>
            
            <th>leaveReason</th>
            <th>Status</th>
           
         
            <th>ManagerComments</th>
            <th>change Status</th>
            </tr>
            {Leave.map(a => <tr>
               <td>{a.leaveId}</td>
                <td>{a.employeeId}</td>
                <td>{a.managerId}</td>
               
                <td>{a.startDate}</td>
                <td>{a.endDate}</td>
                <td>{a.noOfDays}</td>
                <td>{a.leaveType}</td>
                
                <td>{a.leaveReason}</td>
                <td>{a.status}</td>
                {/* <td>{a.managerComments}</td> */}
                <td><Button variant="primary btn-block" onClick={this.Change} type="submit" > Change status</Button></td>
            </tr>
            )}
            </tbody>
           
            
        </table>
        </div>
            // <div>
            //     <form>
            //     <label>Status</label>
            //         <input type="text" name="Status" onChange={(e)=>this.handleChange({status:e.target.value})} placeholder=" Enter your Status"></input>
            //         <br></br>
            //         <label>Manager Comment</label>
            //         <input type="text" name="Status" onChange={(e)=>this.handleChange({status:e.target.value})} placeholder=" Enter your Comments"></input>
            //         <br></br>
            //         <button type="submit" className="button" onClick={this.ApproveDeny} >Apply</button>
                        
            //     </form>
            // </div>
        )
    }
}
